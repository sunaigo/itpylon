CREATE PROCEDURE p_summary_update()
  BEGIN

delete from summary;

insert into summary (type,stisname,stisvalue,apptype)
SELECT '1',DATE_FORMAT(created, '%Y-%m'),count(1)*27,apptype
FROM userinfo 
WHERE apptype='车载'
GROUP BY DATE_FORMAT(created, '%Y-%m')  ,apptype
ORDER BY DATE_FORMAT(created, '%Y-%m') desc limit 30;


insert into summary (type,stisname,stisvalue,apptype)
SELECT '1',DATE_FORMAT(created, '%Y-%m'),count(1)*27,apptype
FROM userinfo 
WHERE apptype='后服务'
GROUP BY DATE_FORMAT(created, '%Y-%m')  ,apptype
ORDER BY DATE_FORMAT(created, '%Y-%m') desc limit 30;

insert into summary (type,stisname,stisvalue,apptype)
select '2',appname,count(1)*27,apptype from userinfo WHERE apptype='车载' GROUP BY appname,apptype ORDER BY count(1)*27 desc limit 10;
insert into summary (type,stisname,stisvalue,apptype)
select '2',appname,count(1)*27,apptype from userinfo WHERE apptype='后服务' GROUP BY appname,apptype ORDER BY count(1)*27 desc limit 10;

insert into summary (type,stisname,stisvalue,apptype)
select '3',sex,count(1)*27,apptype from userinfo WHERE apptype='车载' GROUP BY sex ,apptype ORDER BY count(1)*27 desc limit 4;
insert into summary (type,stisname,stisvalue,apptype)
select '3',sex,count(1)*27,apptype from userinfo WHERE apptype='后服务' GROUP BY sex ,apptype ORDER BY count(1)*27 desc limit 4;

insert into summary (type,stisname,stisvalue,apptype)
select '4',province,count(1)*27,apptype from userinfo WHERE apptype='车载' GROUP BY province ,apptype ORDER BY count(1)*27 desc limit 40;
insert into summary (type,stisname,stisvalue,apptype)
select '4',province,count(1)*27,apptype from userinfo WHERE apptype='后服务' GROUP BY province ,apptype ORDER BY count(1)*27 desc limit 40;

insert into summary (type,stisname,stisvalue,apptype)
select '5',cartype,count(1)*27,apptype from userinfo WHERE apptype='车载' GROUP BY cartype ,apptype ORDER BY count(1)*27 desc limit 15;
insert into summary (type,stisname,stisvalue,apptype)
select '5',cartype,count(1)*27,apptype from userinfo WHERE apptype='后服务' GROUP BY cartype ,apptype ORDER BY count(1)*27 desc limit 15;

END;
